<?php
declare(strict_types=1);
require_once __DIR__ . '/../api/lib/platform-auth.php';
require_once __DIR__ . '/../api/lib/platform-admin.php';
require_once __DIR__ . '/../api/lib/paths.php';
require_once __DIR__ . '/../api/lib/export-control.php';
require_once __DIR__ . '/../api/lib/updater.php';
sec_session();
pauth_require();

 $msg = ''; $ok = ''; $tmpPass = ''; $exportLink = '';
 $updRep = null; $updScan = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $act = $_POST['act'] ?? '';
  if (!csrf_ok($_POST['csrf'] ?? null)) {
    $msg = 'نشست منقضی شده';
  } else try {
    switch ($act) {
      case 'logout':  plat_log('logout'); pauth_logout(); header('Location: index.php'); exit;
      case 'change':  $m = pauth_change($_POST['old'] ?? '', $_POST['p1'] ?? '', $_POST['p2'] ?? '');
                      if ($m === '') { $ok = 'رمز عوض شد'; plat_log('pass_change'); } else $msg = $m; break;
      case 'activate': plat_activate($_POST['slug'] ?? '', max(30, (int)($_POST['days'] ?? 365)));
                       $ok = 'لایسنس فعال شد'; plat_log('activate', ['slug' => $_POST['slug'] ?? '', 'days' => (int)($_POST['days'] ?? 365)]); break;
      case 'suspend':  plat_suspend($_POST['slug'] ?? ''); $ok = 'کافه غیرفعال شد'; plat_log('suspend', ['slug' => $_POST['slug'] ?? '']); break;
      case 'resetpass': $tmpPass = plat_reset_pass($_POST['slug'] ?? '');
                        $ok = 'رمز موقت مدیر کافه ساخته شد'; plat_log('resetpass', ['slug' => $_POST['slug'] ?? '']); break;
      /* v5.0.5-test.1: ریست رمز پرسنل (صندوق‌دار / آشپزخانه) */
      case 'resetuser': $tmpPass = plat_reset_user($_POST['slug'] ?? '', $_POST['uid'] ?? '');
                        $ok = 'رمز موقت پرسنل ساخته شد — «' . htmlspecialchars(plat_user_name($_POST['slug'] ?? '', $_POST['uid'] ?? '')) . '»';
                        plat_log('resetuser', ['slug' => $_POST['slug'] ?? '', 'uid' => $_POST['uid'] ?? '']);
                        break;
      case 'delete':   plat_delete($_POST['slug'] ?? '', ($_POST['final'] ?? '') === '1');
                       $ok = 'کافه حذف شد'; break;
      case 'sweep':    $r = plat_sweep_orphans();
                       $ok = "جاروبرقی: {$r['scanned']} فایل بررسی، {$r['deleted']} حذف، {$r['freed_mb']}MB آزاد شد";
                       plat_log('sweep', $r); break;
      case 'trash':    $n = plat_trash_sweep();
                       $ok = "$n کافهٔ منقضی از سطل زباله پاک شد"; plat_log('trash_sweep', ['n' => $n]); break;

      /* ── v5.0.5-test.4: کنترل کامل کافه‌ها ── */
      case 'renew':      plat_renew($_POST['slug'] ?? '', (int)($_POST['days'] ?? 365));
                         $ok = 'لایسنس تمدید شد'; break;
      case 'extendtrial': plat_extend_trial($_POST['slug'] ?? '', (int)($_POST['days'] ?? 14));
                         $ok = 'دورهٔ آزمایشی تمدید شد'; break;
      case 'rename':     plat_rename($_POST['slug'] ?? '', (string)($_POST['name'] ?? ''));
                         $ok = 'نام کافه عوض شد'; break;
      case 'backupdl':   $bk = plat_backup($_POST['slug'] ?? '');
                         header('Content-Type: application/zip');
                         header('Content-Disposition: attachment; filename="gitiarts-backup-' . basename($bk['path']) . '"');
                         header('Content-Length: ' . (string)filesize($bk['path']));
                         header('Cache-Control: no-store');
                         readfile($bk['path']);
                         exit;
      case 'restore':    plat_restore($_POST['tname'] ?? '');
                         $ok = 'کافه از سطل زباله بازیابی شد'; break;
      case 'trashdel':   plat_trash_delete_one($_POST['tname'] ?? '');
                         $ok = 'حذف قطعی انجام شد'; break;

      /* ── تیکت‌های فایل نصبی ── */
      case 'approve_export':
        $tok = xc_approve((int)($_POST['id'] ?? 0), (string)($_POST['slug'] ?? ''));
        $sch = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $exportLink = $sch . '://' . ($_SERVER['HTTP_HOST'] ?? '')
                    . rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/')
                    . '/export-download.php?t=' . $tok;
        $ok = 'لینک یک‌بارمصرف (۷۲ ساعته) ساخته شد — فقط برای مشتری بفرست';
        break;
      case 'deny_export':
        xc_deny((int)($_POST['id'] ?? 0), (string)($_POST['slug'] ?? ''));
        $ok = 'درخواست رد شد'; break;

      /* ── آپدیتر پنل ── */
      case 'update_scan':
        $updScan = upd_scan();
        $ok = 'اسکن سلامت انجام شد';
        break;
      case 'update_apply':
        $f = $_FILES['upzip'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK)
          throw new RuntimeException('فایل آپدیت دریافت نشد — حجم زیپ باید زیر سقف آپلود هاست باشد');
        if ((int)$f['size'] > 48 * 1024 * 1024)
          throw new RuntimeException('فایل آپدیت بزرگ‌تر از ۴۸ مگابایت است');
        $updRep = upd_apply($f['tmp_name'], ($_POST['force'] ?? '') === '1');
        plat_log('update_apply', ['version' => (string)($updRep['version'] ?? ''), 'applied' => (int)($updRep['applied'] ?? 0)]);
        $ok = "آپدیت نسخهٔ {$updRep['version']} نصب شد ({$updRep['applied']} فایل) — پشتیبان گرفته شد";
        break;
    }
  } catch (Throwable $e) { $msg = $e->getMessage(); }
}

 $cfg  = p_config();
 $list = plat_list();
 $reqs = xc_load()['reqs'];
 $aud  = xc_audit_tail(60);
 $stats = plat_stats();
 $trash = plat_trash_list();
 $totalMb = $stats['total_mb'];
 $setupStill = (string)($cfg['setup_key'] ?? '') !== '';
 $names = []; foreach ($list as $x) $names[$x['slug']] = $x['name'];
 try { $updVer = upd_current_version(); } catch (Throwable $e) { $updVer = '?'; }
 $updCfgVer = upd_config_version();
 $updMan    = upd_manifest();
 $updLogs   = upd_log_load();
 $updBks    = glob(p_root() . '/data/backups/*.zip') ?: [];
 usort($updBks, fn($a, $b) => filemtime($b) <=> filemtime($a));
 $updBk     = $updBks[0] ?? null;

/* برچسب فارسی رویدادهای لاگ */
function plat_ev_fa(string $ev): string {
  static $m = [
    'plat.activate'=>'فعال‌سازی لایسنس','plat.suspend'=>'تعلیق کافه','plat.rename'=>'تغییر نام کافه',
    'plat.extend_trial'=>'تمدید دورهٔ آزمایشی','plat.renew'=>'تمدید لایسنس','plat.resetpass'=>'ریست رمز مدیر کافه',
    'plat.resetuser'=>'ریست رمز پرسنل','plat.delete'=>'حذف کافه (به سطل)','plat.restore'=>'بازیابی از سطل زباله',
    'plat.trash_delete'=>'حذف قطعی از سطل','plat.backup'=>'پشتیبان‌گیری کافه','plat.sweep'=>'جارو رسانه‌های یتیم',
    'plat.trash_sweep'=>'پاک‌سازی سطل منقضی','plat.setup'=>'راه‌اندازی اولیهٔ پنل','plat.login'=>'ورود موفق',
    'plat.login_fail'=>'تلاش ناموفق ورود','plat.logout'=>'خروج از پنل','plat.pass_change'=>'تغییر رمز مدیر',
    'plat.update_apply'=>'نصب آپدیت','request'=>'درخواست فایل نصبی','approve'=>'تأیید درخواست',
    'deny'=>'رد درخواست','export-used'=>'دانلود بسته',
  ];
  return $m[$ev] ?? $ev;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>پنل GitiArts — مدیریت پلتفرم</title>
<link rel="stylesheet" href="platform.css">
</head>
<body>
<div class="wrap wide">
  <div class="card">
    <div class="logo">🌿 GitiArts — مدیریت پلتفرم</div>
    <?php if ($setupStill): ?><p class="warn">🔒 نصب انجام شده — مقدار <b>setup_key</b> را در config.php خالی '' کنید.</p><?php endif; ?>
    <?php if ($msg): ?><p class="err"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
    <?php if ($ok): ?><p class="ok"><?= htmlspecialchars($ok) ?></p><?php endif; ?>
    <?php if ($tmpPass): ?>
      <p class="tmp">🔐 رمز موقت کافه‌دار: <b dir="ltr"><?= htmlspecialchars($tmpPass) ?></b>
      <small>— همین را به مشتری بده؛ بعد از ورود بهتر است رمزش را عوض کند</small></p>
    <?php endif; ?>
    <?php if ($exportLink): ?>
      <p class="tmp">📦 لینک دانلود یک‌بارمصرف (۷۲ ساعت):<br>
      <textarea id="expLink" readonly style="width:100%;box-sizing:border-box;direction:ltr;font-size:11px;padding:8px;border-radius:8px;border:1px solid #CBBB99;height:52px"><?= htmlspecialchars($exportLink) ?></textarea>
      <small><button type="button" class="btn2" onclick="var t=document.getElementById('expLink');t.select();document.execCommand('copy');this.textContent='کپی شد ✓'">📋 کپی لینک</button>
      — این لینک را فقط برای مشتریِ همین کافه بفرست (تلگرام/پیامک)؛ بعد از یک بار دانلود یا ۷۲ ساعت باطل می‌شود</small></p>
    <?php endif; ?>

    <?php if ($stats['expiring_list']): ?>
      <div class="warn">⏳ لایسنس‌های رو به انقضا (۷ روز آینده):
        <?php foreach ($stats['expiring_list'] as $e): ?>
          <b><?= htmlspecialchars($e['name']) ?></b> (<?= (int)$e['days_left'] ?> روز)<?= $e === end($stats['expiring_list']) ? '' : ' ·' ?>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="stats">
      <div class="st"><b><?= $stats['total'] ?></b><span>کافه</span></div>
      <div class="st"><b><?= $stats['active'] ?></b><span>فعال</span></div>
      <div class="st"><b><?= $stats['trial'] ?></b><span>آزمایشی</span></div>
      <div class="st"><b><?= $stats['suspended'] ?></b><span>معلق</span></div>
      <div class="st<?= $stats['expiring'] ? ' hot' : '' ?>"><b><?= $stats['expiring'] ?></b><span>نزدیک انقضا</span></div>
      <div class="st"><b><?= $stats['orders24h'] ?></b><span>سفارش ۲۴ساعت</span></div>
      <div class="st"><b><?= $stats['orders'] ?></b><span>سفارش کل</span></div>
      <div class="st"><b><?= $stats['customers'] ?></b><span>مشتری</span></div>
      <div class="st"><b><?= $stats['items'] ?></b><span>آیتم منو</span></div>
      <div class="st"><b><?= round($totalMb, 1) ?></b><span>MB مصرفی</span></div>
      <div class="st"><b><?= $cfg['limits']['upload_mb'] * max(1, $stats['total']) ?></b><span>MB سقف مجموع</span></div>
    </div>

    <div class="tools">
      <form method="post"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="act" value="sweep">
        <button class="btn2">🧹 جاروبرقی رسانه‌های یتیم</button></form>
      <form method="post"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="act" value="trash">
        <button class="btn2">🗑 پاک‌سازی سطل زبالهٔ منقضی</button></form>
    </div>
    <div class="sec">
      <h2>⬆️ بروزرسانی و سلامت</h2>
      <p class="mini">
        نسخهٔ نصب‌شده: <b dir="ltr"><?= htmlspecialchars($updVer) ?></b>
        <?= $updCfgVer !== '' && $updCfgVer !== $updVer ? '<span class="mini">· config: <span dir="ltr">' . htmlspecialchars($updCfgVer) . '</span></span>' : '' ?>
        <?= !empty($updMan['released']) ? '· انتشار: ' . htmlspecialchars((string)$updMan['released']) : '' ?>
      </p>
      <?php if (!empty($updMan['notes_fa'])): ?><p class="mini" dir="auto">📝 <?= htmlspecialchars((string)$updMan['notes_fa']) ?></p><?php endif; ?>
      <?php if ($updBk): ?><p class="mini">💾 آخرین پشتیبان: <span dir="ltr"><?= htmlspecialchars(basename($updBk)) ?></span> (<?= date('m-d H:i', (int)filemtime($updBk)) ?> — <?= round((int)filesize($updBk) / 1048576, 1) ?> MB)</p><?php endif; ?>

      <form method="post" enctype="multipart/form-data" style="margin:10px 0" onsubmit="return confirm('آپدیت نصب شود؟\nابتدا پشتیبان خودکار گرفته می‌شود و دادهٔ زندهٔ کافه‌ها دست‌نخورده می‌ماند.')">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="act" value="update_apply">
        <input type="file" name="upzip" accept=".zip" required style="max-width:280px">
        <button class="btn2">⬆️ نصب آپدیت</button>
        <small class="mini"> — فایل زیپ آپدیت را از پشتیبانی دریافت و همین‌جا آپلود کنید؛ بدون FTP</small>
      </form>

      <form method="post" style="margin:6px 0">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="act" value="update_scan">
        <button class="btn2">🩺 اسکن سلامت فایل‌ها</button>
        <small class="mini"> — مقایسهٔ فایل‌های هسته با چک‌سام بستهٔ نصب‌شده</small>
      </form>

      <?php if (is_array($updRep) && $updRep['ok']): ?>
        <div class="ten" style="margin-top:8px">
          <div class="ten-h"><b>✅ نتیجهٔ نصب — نسخهٔ <span dir="ltr"><?= htmlspecialchars($updRep['version']) ?></span></b></div>
          <div class="ten-meta">
            <span><?= (int)$updRep['applied'] ?> فایل اعمال شد</span>
            <span><?= count($updRep['skipped']) ?> فایل حفاظت‌شده رد شد</span>
            <?php if ($updRep['deleted']): ?><span><?= count($updRep['deleted']) ?> فایل زائد حذف شد</span><?php endif; ?>
            <span>پشتیبان: <span dir="ltr"><?= htmlspecialchars(basename($updRep['backup'])) ?></span></span>
          </div>
          <?php if ($updRep['applied_list']): ?><p class="mini" dir="ltr">applied: <?= htmlspecialchars(implode(', ', $updRep['applied_list'])) ?><?= $updRep['applied'] > count($updRep['applied_list']) ? ' …' : '' ?></p><?php endif; ?>
          <?php if ($updRep['skipped']): ?><p class="mini" dir="ltr">protected: <?= htmlspecialchars(implode(', ', array_keys($updRep['skipped']))) ?></p><?php endif; ?>
          <?php if ($updRep['deleted']): ?><p class="mini" dir="ltr">removed: <?= htmlspecialchars(implode(', ', $updRep['deleted'])) ?></p><?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if (is_array($updScan)): ?>
        <div class="ten" style="margin-top:8px">
          <div class="ten-h">
            <b>🩺 اسکن سلامت</b>
            <span class="pill <?= $updScan['healthy'] ? 'ok' : 'warn' ?>"><?= $updScan['healthy'] ? 'همه‌چیز سالم' : 'اختلاف پیدا شد' ?></span>
          </div>
          <div class="ten-meta">
            <span>مبنا: چک‌سام نسخهٔ <span dir="ltr"><?= htmlspecialchars($updScan['version']) ?></span></span>
            <span><?= (int)$updScan['ok'] ?>/<?= (int)$updScan['total'] ?> فایل سالم</span>
          </div>
          <?php if ($updScan['modified']): ?><p class="mini" dir="ltr">modified: <?= htmlspecialchars(implode(', ', array_slice($updScan['modified'], 0, 30))) ?><?= count($updScan['modified']) > 30 ? ' …' : '' ?></p><?php endif; ?>
          <?php if ($updScan['missing']): ?><p class="mini" dir="ltr">missing: <?= htmlspecialchars(implode(', ', array_slice($updScan['missing'], 0, 30))) ?><?= count($updScan['missing']) > 30 ? ' …' : '' ?></p><?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($updLogs): ?>
        <p class="mini">آخرین نصب: <?= date('m-d H:i', (int)$updLogs[0]['ts']) ?> — نسخهٔ <span dir="ltr"><?= htmlspecialchars((string)($updLogs[0]['to'] ?? '?')) ?></span> (<?= (int)($updLogs[0]['applied'] ?? 0) ?> فایل)</p>
      <?php endif; ?>
    </div>

    <div class="sec">
      <h2>🎫 درخواست‌های فایل نصبی (تیکت)</h2>
      <?php if (!$reqs): ?><p class="mini">هیچ درخواستی ثبت نشده.</p><?php endif; ?>
      <?php foreach (array_reverse($reqs) as $r): $st = $r['status'] ?? ''; ?>
        <div class="ten">
          <div class="ten-h">
            <b>#<?= (int)$r['id'] ?> — <?= htmlspecialchars($names[$r['slug']] ?? $r['slug']) ?>
              <span class="mini" dir="ltr">/<?= htmlspecialchars($r['slug']) ?></span></b>
            <?php if ($st==='pending'): ?><span class="pill warn">در انتظار</span>
            <?php elseif ($st==='approved'): ?><span class="pill ok"><?= !empty($r['used']) ? 'دانلود شده' : 'تأییدشده — لینک فعال' ?></span>
            <?php elseif ($st==='denied'): ?><span class="pill bad">ردشده</span><?php endif; ?>
          </div>
          <div class="ten-meta">
            <span>تاریخ: <?= date('Y-m-d H:i', (int)($r['ts'] ?? 0)) ?></span>
            <?php if (!empty($r['note'])): ?><span dir="auto">یادداشت مشتری: <?= htmlspecialchars($r['note']) ?></span><?php endif; ?>
            <?php if ($st==='approved'): ?><span>انقضای لینک: <?= date('Y-m-d H:i', (int)($r['expires'] ?? 0)) ?></span><?php endif; ?>
          </div>
          <?php if ($st==='pending'): ?>
          <div class="ten-ops">
            <form method="post" class="inline" onsubmit="return confirm('لینک یک‌بارمصرف ۷۲ ساعته ساخته شود؟')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="approve_export">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="slug" value="<?= htmlspecialchars($r['slug']) ?>">
              <button class="btn2">✅ تأیید و ساخت لینک</button></form>
            <form method="post" class="inline" onsubmit="return confirm('رد شود؟')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="deny_export">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="slug" value="<?= htmlspecialchars($r['slug']) ?>">
              <button class="btn2 red">✖ رد</button></form>
          </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="sec">
      <h2>کافه‌های ثبت‌شده</h2>
      <div class="fwrap">
        <input type="text" id="q" placeholder="🔍 جستجوی نام یا آدرس کافه…" autocomplete="off">
        <div class="chips">
          <button type="button" class="chip on" data-f="all">همه</button>
          <button type="button" class="chip" data-f="active">فعال</button>
          <button type="button" class="chip" data-f="trial">آزمایشی</button>
          <button type="button" class="chip" data-f="suspended">معلق</button>
          <button type="button" class="chip" data-f="expiring">نزدیک انقضا</button>
        </div>
      </div>
      <?php if (!$list): ?><p class="mini">هنوز کافه‌ای ثبت نشده.</p><?php endif; ?>
      <?php foreach ($list as $x): $lic = $x['lic']; $det = plat_details($x['slug']);
            $isExp = ($lic['status']==='active' && $lic['days_left']!==null && $lic['days_left']<=7)
                  || ($lic['status']==='trial'  && $lic['days_left']!==null && $lic['days_left']<=3); ?>
        <div class="ten" data-cafe="<?= htmlspecialchars(mb_strtolower($x['name'] . ' ' . $x['slug'])) ?>" data-st="<?= htmlspecialchars($lic['status']) ?>" data-exp="<?= $isExp ? '1' : '0' ?>">
          <div class="ten-h">
            <b><?= htmlspecialchars($x['name']) ?></b>
            <span class="pill <?= $x['active'] ? 'ok' : 'bad' ?>"><?= $x['active'] ? 'فعال' : 'غیرفعال' ?></span>
            <?php if ($det['pending_export']): ?><span class="pill warn">تیکت در انتظار</span><?php endif; ?>
          </div>
          <div class="ten-meta" dir="auto">
            <span>آدرس: <a href="<?= htmlspecialchars($x['url']) ?>" target="_blank" dir="ltr">/<?= htmlspecialchars($x['slug']) ?>/</a></span>
            <span><a href="<?= htmlspecialchars($x['url']) ?>hub.php" target="_blank">پنل کافه‌دار ↗</a></span>
            <span>لایسنس:
              <?php if ($lic['status']==='trial'): ?>
                <span class="pill warn">آزمایشی — <?= $lic['days_left'] ?> روز مانده</span>
              <?php elseif ($lic['status']==='active'): ?>
                <span class="pill ok">فعال — <?= $lic['days_left'] ?> روز</span>
              <?php elseif ($lic['status']==='suspended'): ?>
                <span class="pill bad">معلق</span>
              <?php else: ?>
                <span class="pill bad"><?= htmlspecialchars($lic['status']) ?></span>
              <?php endif; ?>
            </span>
            <span>فضا: <b><?= $x['size_mb'] ?></b> MB</span>
          </div>
          <div class="ten-meta" dir="auto">
            <span>🍽 <?= $det['items'] ?> آیتم / <?= $det['cats'] ?> دسته</span>
            <span>🧾 <?= $det['orders'] ?> سفارش (<?= $det['orders24h'] ?> در ۲۴س)</span>
            <span>👥 <?= $det['customers'] ?> مشتری</span>
            <?php if ($det['resv_pending']): ?><span class="pill warn">⏰ <?= $det['resv_pending'] ?> رزرو در انتظار</span><?php endif; ?>
            <?php if ($det['last_order']): ?><span>آخرین سفارش: <?= date('m-d H:i', (int)($det['last_order'] / 1000)) ?></span><?php endif; ?>
          </div>
          <div class="ten-ops">
            <?php if ($lic['status'] !== 'active'): ?>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="activate"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <label class="mini">مدت (روز):</label>
              <input type="number" name="days" value="365" min="30" max="3650" style="width:70px">
              <button class="btn2">✅ فعال‌سازی لایسنس</button></form>
            <?php else: ?>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="renew"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <label class="mini">تمدید (روز):</label>
              <input type="number" name="days" value="365" min="1" max="3650" style="width:64px">
              <button class="btn2">🔄 تمدید لایسنس</button></form>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="suspend"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <button class="btn2">⏸ معلق</button></form>
            <?php endif; ?>
            <?php if ($lic['status'] === 'trial'): ?>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="extendtrial"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <label class="mini">+آزمایش (روز):</label>
              <input type="number" name="days" value="14" min="1" max="3650" style="width:56px">
              <button class="btn2">⏱ تمدید آزمایشی</button></form>
            <?php endif; ?>
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="resetpass"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <button class="btn2">🔑 ریست رمز مدیر</button></form>
            <form method="post" class="inline" onsubmit="return confirm('پشتیبان کامل «<?= htmlspecialchars($x['name']) ?>» دانلود شود؟ (زیپ قابل‌نصب مستقل)')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="backupdl"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <button class="btn2">📦 پشتیبان</button></form>
            <form method="post" class="inline" onsubmit="return confirm('حذف <?= htmlspecialchars($x['name']) ?>؟ (به سطل زباله می‌رود، <?= $cfg['limits']['grace_days'] ?> روز قابل بازگشت)')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="delete"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <input type="hidden" name="final" value="0">
              <button class="btn2 red">🗑 حذف</button></form>
          </div>
          <div class="ten-ops" style="margin-top:6px">
            <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="rename"><input type="hidden" name="slug" value="<?= $x['slug'] ?>">
              <label class="mini">✏️ نام:</label>
              <input type="text" name="name" value="<?= htmlspecialchars($x['name']) ?>" maxlength="60" style="width:150px;padding:5px;border:1px solid #CBBB99;border-radius:8px;font:inherit">
              <button class="btn2">ثبت نام</button></form>
          </div>
          <?php /* جزئیات کامل + پرسنل */ ?>
          <details style="margin-top:8px">
            <summary class="mini" style="cursor:pointer;font-weight:800">📊 جزئیات کافه</summary>
            <div class="dgrid">
              <span>نام برند منو: <b><?= htmlspecialchars($det['brand'] ?: '—') ?></b></span>
              <span>راه‌اندازی ویزارد: <b><?= $det['setup_done'] ? 'انجام شده' : 'هنوز نشده' ?></b></span>
              <span>تاریخ ثبت: <b><?= $det['created'] ? date('Y-m-d', (int)($det['created'] / 1000)) : '—' ?></b></span>
              <span>پرسنل: <b><?= $det['staff'] ?></b> کاربر</span>
              <span>رزرو در انتظار تأیید: <b><?= $det['resv_pending'] ?></b></span>
              <span>حجم کل: <b><?= $x['size_mb'] ?></b> MB از <?= $cfg['limits']['upload_mb'] ?> MB</span>
            </div>
          </details>
          <?php $staff = plat_users($x['slug']); if ($staff): ?>
          <details style="margin-top:8px">
            <summary class="mini" style="cursor:pointer;font-weight:800">👷 پرسنل (صندوق / آشپزخانه) — ریست رمز: <?= count($staff) ?> کاربر</summary>
            <?php foreach ($staff as $su): ?>
            <div class="mini" style="display:flex;justify-content:space-between;align-items:center;gap:8px;border-bottom:1px dashed #DFD2B6;padding:4px 0">
              <span>«<?= htmlspecialchars($su['name']) ?>»<?= $su['phone'] ? ' · <span dir="ltr">' . htmlspecialchars($su['phone']) . '</span>' : '' ?><?= $su['haspass'] ? '' : ' · بدون رمز' ?></span>
              <form method="post" class="inline" onsubmit="return confirm('رمز «<?= htmlspecialchars($su['name']) ?>» ریست شود؟ رمز موقت همین‌جا نشان داده می‌شود.')">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="act" value="resetuser">
                <input type="hidden" name="slug" value="<?= $x['slug'] ?>">
                <input type="hidden" name="uid" value="<?= htmlspecialchars($su['id']) ?>">
                <button class="btn2">🔑 ریست رمز</button></form>
            </div>
            <?php endforeach; ?>
          </details>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="sec">
      <h2>♻️ سطل زباله (کافه‌های حذف‌شده — <?= $cfg['limits']['grace_days'] ?> روز فرصت بازگشت)</h2>
      <?php if (!$trash): ?><p class="mini">سطل زباله خالی است.</p><?php endif; ?>
      <?php foreach ($trash as $t): ?>
        <div class="ten">
          <div class="ten-h">
            <b><?= htmlspecialchars($t['name']) ?> <span class="mini" dir="ltr">/<?= htmlspecialchars($t['slug']) ?></span></b>
            <?php if ($t['taken']): ?><span class="pill warn">اسلاگ اشغال شده</span>
            <?php else: ?><span class="pill ok">قابل بازیابی</span><?php endif; ?>
          </div>
          <div class="ten-meta">
            <span>حذف: <?= date('Y-m-d H:i', (int)$t['ts']) ?></span>
            <span>فضا: <?= $t['size_mb'] ?> MB</span>
            <span>وضعیت لایسنس هنگام حذف: <?= htmlspecialchars($t['lic']) ?></span>
          </div>
          <div class="ten-ops">
            <?php if (!$t['taken']): ?>
            <form method="post" class="inline" onsubmit="return confirm('کافه به پلتفرم برگردد؟')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="restore">
              <input type="hidden" name="tname" value="<?= htmlspecialchars($t['tname']) ?>">
              <button class="btn2">♻️ بازیابی</button></form>
            <?php endif; ?>
            <form method="post" class="inline" onsubmit="return confirm('حذف قطعی؟ دیگر هیچ راه بازگشتی نیست!')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="act" value="trashdel">
              <input type="hidden" name="tname" value="<?= htmlspecialchars($t['tname']) ?>">
              <button class="btn2 red">🔥 حذف قطعی</button></form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="sec">
      <h2>📜 لاگ عملیات (۶۰ رویداد آخر)</h2>
      <?php if (!$aud): ?><p class="mini">لاگی نیست.</p><?php endif; ?>
      <?php foreach ($aud as $a): ?>
        <div class="mini" style="border-bottom:1px dashed #DFD2B6;padding:3px 0"><?= date('m-d H:i', (int)$a['ts']) ?> — <?= htmlspecialchars(plat_ev_fa((string)$a['ev'])) ?> <span dir="ltr" class="mini"><?= htmlspecialchars(json_encode($a['d'] ?? [], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?></span></div>
      <?php endforeach; ?>
    </div>

    <div class="sec">
      <h2>تغییر رمز مدیر</h2>
      <?php /* v5.0.5-test.3: وضعیت ورود دومرحله‌ای (کد یکبارمصرف پیامکی) */ ?>
      <p class="mini">🔒 ورود دومرحله‌ای (کد پیامکی):
        <?= pauth_otp_enabled()
            ? '<span class="pill ok">فعال — ارسال به <span dir="ltr">' . htmlspecialchars(pauth_otp_mobile_masked()) . '</span></span>'
            : '<span class="pill warn">غیرفعال</span> — برای فعال‌سازی «security.admin_mobile» و کلید پیامک را در config.php پر کنید' ?>
      </p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="act" value="change">
        <label>رمز فعلی<input type="password" name="old" required></label>
        <label>رمز جدید<input type="password" name="p1" required></label>
        <label>تکرار رمز جدید<input type="password" name="p2" required></label>
        <button class="btn2">ثبت رمز جدید</button>
      </form>
    </div>

    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="act" value="logout">
      <button class="btn2 red">خروج از پنل</button>
    </form>

    <p class="foot">سِرو · GitiArts · پشتیبانی تلگرام: <span dir="ltr">+98 919 834 5661</span></p>
  </div>
</div>
<script>
function cafFilter(){
  var q=(document.getElementById('q').value||'').trim().toLowerCase();
  var on=document.querySelector('.chip.on');
  var st=on?on.getAttribute('data-f'):'all';
  document.querySelectorAll('div.ten[data-cafe]').forEach(function(el){
    var okQ=!q||el.getAttribute('data-cafe').indexOf(q)>=0;
    var okS=st==='all'||el.getAttribute('data-st')===st||(st==='expiring'&&el.getAttribute('data-exp')==='1');
    el.style.display=(okQ&&okS)?'':'none';
  });
}
document.addEventListener('DOMContentLoaded',function(){
  var q=document.getElementById('q');
  if(q)q.addEventListener('input',cafFilter);
  document.querySelectorAll('.chip').forEach(function(c){c.addEventListener('click',function(){
    document.querySelectorAll('.chip').forEach(function(x){x.classList.remove('on')});
    c.classList.add('on');cafFilter();
  });});
});
</script>
</body>
</html>
